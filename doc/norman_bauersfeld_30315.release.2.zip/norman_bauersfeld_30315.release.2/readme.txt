T1_* documentation of "pipeline"
T2_* documentation of "fluxen"

idb notebooks
idb/queries queries in *.flux and query results in *.flux.txt

opc opc server and client 
opc/flows node-red flow to send opc to mqtt
node
tclab.model.node.3 node training by cyclic thermo curve

pinn
tclab.model.pinn.3 pinn training by cyclic thermo curve
tclab.model.pinn.4 pinn training by random thermo curve

addon
tclab.model.inside.3 inside analysis of nets
tclab.model.fodpt.3 fodpt parameter estimation and above
tclab.model.data.3 data generator for simulation
tclab.model.animate.3 net estimation animation by monitoring

classes 
_*.py model, helper, balance classes